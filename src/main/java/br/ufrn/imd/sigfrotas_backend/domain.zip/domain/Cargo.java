package br.ufrn.imd.sigfrotas_backend.domain;

public enum Cargo {
    GERENTE,
    MOTORISTA,
    CLIENTE
}
